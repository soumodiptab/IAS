import requests
from hackathon_1_prepare.samples.app.app.sensor_controller import sensor_recieve
from models import model_call


while(True):
        sensor_recieve(0)
        print('Sample application')