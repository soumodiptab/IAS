import modulefinder

from flask import request





dta1, dta2 = 1, 2
model_call(0, dta1, dta2)

def get_sensor_data(idx):


var=get_sensor_data(0)
